package com.example.instagramclone.util;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class bottomNavigationDetail {
    private static final String TAG ="BottomNavigationDetail";
    public static void bottomNavigation(BottomNavigationView bottomNavigationView){
    }
}
